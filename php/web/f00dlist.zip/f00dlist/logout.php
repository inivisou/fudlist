<?php
/**
 * LOGOUT.PHP
 * ==========
 * Cierra la sesión del usuario y redirige al login.
 */

require_once 'config/config.php';
require_once 'includes/auth.php';

// 1. Llamar a la función de logout definida en auth.php
logoutUser();

// 2. Redirigir al login con un mensaje (opcional)
// Podemos pasar un parámetro en la URL para mostrar un mensaje en login.php
redirect(url('login.php?logout=1'));
?>